# Gudiya Taxi Partner implementation update

## Included in this source update
- Duties are stored in the Gudiya PostgreSQL backend; the app refreshes the duty feed every 20 seconds while the search screen is open.
- Duty cards show the poster's phone and offer direct dial, WhatsApp with duty details prefilled, and sharing to a separately entered WhatsApp number.
- Non-subscribers see a five-minute visible countdown. After the free window expires, the UI hides private addresses, contact, notes and payout; the API also stops returning those private fields. Active subscribers retain access.
- Membership webhook updates the subscription period so active membership checks work.
- Login/register use Gudiya-specific local storage keys.
- Driver document submission requires Aadhaar, driving licence and vehicle RC; vendor submission requires Aadhaar; driver+vendor submission accepts all four document entries (separate driver Aadhaar and vendor Aadhaar records).
- Backend initializes `schema.sql` before listening, so missing database tables do not surface as a generic login Server error on a fresh database.
- JSON body size is 25 MB to support four document uploads of up to 4 MB each after Base64 encoding.

## Deployment requirements
- Deploy `backend/` to the existing Gudiya API service and ensure `DATABASE_URL` and a 32+ character `JWT_SECRET` are configured.
- Configure Razorpay key/secret, the three membership plan IDs and the webhook secret before taking subscription payments. Membership must only activate after verified webhook delivery.
- This package was syntax-checked with Node.js; an Android APK build and live PostgreSQL/Render integration test must still run in GitHub Actions/Render.


## Real-time duty list refresh
Duty search now refreshes from the shared API every 3 seconds while visible, and refreshes on app resume/focus. It avoids overlapping silent refresh requests. This is near-real-time polling; backend deployment and APK build/testing are required.

## Firebase Cloud Messaging integration (initial implementation)
- Android Firebase configuration is in `app/google-services.json` and matches `com.gudiyataxipartner`.
- Android includes Firebase Messaging, requests Android 13+ notification permission, creates a high-importance notification channel with sound/vibration, and displays data-message notifications.
- After password login (or app resume/start with an existing session), the app obtains its FCM token and registers it through `POST /api/push/register-token`.
- Backend schema stores tokens; code sends data-only high-priority push notifications for newly posted duties, duty acceptance, and document review status changes.
- To actually send pushes, deploy the backend changes to the API service and set `FIREBASE_SERVICE_ACCOUNT_JSON` as a Render secret containing the Firebase service-account JSON. Never commit this private service-account key to GitHub.
- FCM delivery is not considered verified until backend deployment, Render secret setup, a successful GitHub Actions APK build, notification permission approval on the phone, and end-to-end testing on a second account/device. Admin “mark paid” notifications are not implemented in this API source because this backend has no admin paid-status endpoint.


## Welcome banner update (2026-10-25)
- The home banner uses the logged-in user’s actual name in “प्रिय [नाम] जी, Gudiya Taxi Partner में आपका हार्दिक स्वागत है!”
- The finalized slogan is displayed underneath with a highlighted, high-contrast design: “हर साथी की अपनी पहचान, हर रिश्ते में विश्वास — यही है Gudiya Taxi Partner की खास बात।”
- The profile information areas show only the user name and contact number.
- Payment UI remains Razorpay AutoPay-only; no UPI ID field is present. This source ZIP alone does not deploy backend changes or prove Razorpay is configured live.
