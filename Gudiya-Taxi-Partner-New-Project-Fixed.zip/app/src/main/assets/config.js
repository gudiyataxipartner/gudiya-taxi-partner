// Live Taxi Mitra API
window.TAXI_MITRA_API_BASE = 'https://taxi-mitra-demo.onrender.com';
