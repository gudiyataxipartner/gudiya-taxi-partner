# Membership and duty lock fix

- Backend membership evaluation is centralized in `backend/src/server.js` and honors an explicit Admin Paid/Unpaid override first.
- Active `manual_upi` memberships require a verified provider payment reference and an unexpired period.
- Server-issued `admin_extension` and `referral_reward` memberships are accepted only while active and unexpired.
- `/api/duties` returns the server membership decision alongside duties. Full private duty/contact fields remain server-gated.
- The app countdown refreshes duty data when the five-minute window reaches zero; it does not locally reveal private contact details.

Deploy the backend source to the API repository/Render first, then build and install the Android app. The production database and the actual signed-in account still need an end-to-end check after deployment.
