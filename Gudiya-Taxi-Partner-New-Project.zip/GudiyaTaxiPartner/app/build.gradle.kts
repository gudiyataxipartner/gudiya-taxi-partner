plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.gudiyataxipartner"
    compileSdk = 35

    // Required because MainActivity uses BuildConfig.VERSION_NAME for update checks.
    buildFeatures {
        buildConfig = true
    }

    defaultConfig {
        applicationId = "com.gudiyataxipartner"
        minSdk = 24
        targetSdk = 35
        versionCode = 11
        versionName = "1.1.9"
    }

    signingConfigs {
        create("stableRelease") {
            storeFile = file("gudiya-release.jks")
            storePassword = System.getenv("ANDROID_KEYSTORE_PASSWORD") ?: ""
            keyAlias = System.getenv("ANDROID_KEY_ALIAS") ?: "gudiya-release"
            keyPassword = System.getenv("ANDROID_KEY_PASSWORD") ?: ""
        }
    }

    buildTypes {
        getByName("debug") {
            // Keep the same stable signing identity for every APK distributed from GitHub.
            signingConfig = signingConfigs.getByName("stableRelease")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}


dependencies {
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-messaging")
}
