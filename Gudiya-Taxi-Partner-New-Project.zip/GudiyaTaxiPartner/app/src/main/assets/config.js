// Gudiya Taxi Partner production API
window.GUDIYA_API_BASE = 'https://gudiya-taxi-partner-api-1.onrender.com';
