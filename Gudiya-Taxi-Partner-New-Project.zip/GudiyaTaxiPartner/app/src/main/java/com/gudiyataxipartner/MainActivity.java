package com.gudiyataxipartner;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.JavascriptInterface;
import android.content.SharedPreferences;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import android.graphics.Color;
import android.view.Window;
import android.widget.Toast;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.Manifest;
import android.content.pm.PackageManager;
import com.google.firebase.messaging.FirebaseMessaging;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 4107;
    private static final String PREFS = "gudiya_taxi_partner_local_data";
    private static final String DUTIES_KEY = "local_duties_v1";

    private static final int NOTIFICATION_PERMISSION_REQUEST = 4208;

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager == null || manager.getNotificationChannel(GudiyaMessagingService.CHANNEL_ID) != null) return;
            NotificationChannel channel = new NotificationChannel(
                GudiyaMessagingService.CHANNEL_ID, "Gudiya Taxi Partner updates", NotificationManager.IMPORTANCE_HIGH);
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{0, 500, 250, 500});
            channel.setSound(android.provider.Settings.System.DEFAULT_NOTIFICATION_URI,
                new android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            manager.createNotificationChannel(channel);
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
        }
    }

    @JavascriptInterface
    public void saveDutyImportSession(String apiBase, String token) {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        prefs.edit().putString("duty_import_api", apiBase == null ? "" : apiBase.replaceAll("/$", ""))
            .putString("duty_import_token", token == null ? "" : token).apply();
    }

    @JavascriptInterface
    public void openWhatsAppDutyPermission() {
        try {
            Intent intent = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Notification Access सेटिंग नहीं खुल सकी।", Toast.LENGTH_LONG).show();
        }
    }

    @JavascriptInterface
    public boolean isWhatsAppDutyPermissionEnabled() {
        String enabled = android.provider.Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return enabled != null && enabled.contains(getPackageName());
    }

    @JavascriptInterface
    public void registerForPush() {
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
            if (!task.isSuccessful() || task.getResult() == null || webView == null) return;
            String token = task.getResult().replace("\\", "\\\\").replace("\"", "\\\"");
            runOnUiThread(() -> {
                if (webView != null) webView.evaluateJavascript("window.onNativeFcmToken && window.onNativeFcmToken(\"" + token + "\")", null);
            });
        });
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createNotificationChannel();
        requestNotificationPermission();
        getWindow().setStatusBarColor(Color.rgb(9, 43, 58));
        getWindow().setNavigationBarColor(Color.rgb(9, 43, 58));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(245, 248, 250));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(this, "GudiyaNative");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("upi".equalsIgnoreCase(uri.getScheme())) {
                    openExternalPayment(uri);
                    return true;
                }
                if ("tel".equalsIgnoreCase(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_DIAL, uri)); }
                    catch (Exception ignored) { }
                    return true;
                }
                if ("https".equalsIgnoreCase(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (Exception ignored) { }
                    return true;
                }
                return !"file".equalsIgnoreCase(uri.getScheme());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Uri uri = Uri.parse(url);
                if ("upi".equalsIgnoreCase(uri.getScheme())) {
                    openExternalPayment(uri);
                    return true;
                }
                if ("tel".equalsIgnoreCase(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_DIAL, uri)); }
                    catch (Exception ignored) { }
                    return true;
                }
                if ("https".equalsIgnoreCase(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (Exception ignored) { }
                    return true;
                }
                return !"file".equalsIgnoreCase(uri.getScheme());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent;
                try {
                    intent = params.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception firstError) {
                    try {
                        intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("*/*");
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivityForResult(Intent.createChooser(intent, "दस्तावेज़ चुनें"), FILE_CHOOSER_REQUEST);
                        return true;
                    } catch (Exception documentError) {
                      try {
                        intent = new Intent(Intent.ACTION_GET_CONTENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("*/*");
                        startActivityForResult(Intent.createChooser(intent, "दस्तावेज़ चुनें"), FILE_CHOOSER_REQUEST);
                        return true;
                      } catch (Exception secondError) {
                        if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                        filePathCallback = null;
                        Toast.makeText(MainActivity.this, "फाइल चुनने के लिए File Manager उपलब्ध नहीं है।", Toast.LENGTH_LONG).show();
                        return true;
                      }
                    }
                }
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        checkForAppUpdate();
    }

    // Checks the public GitHub Release and offers a user-confirmed APK download.
    // Android still asks the user to confirm installing the downloaded APK.
    private void checkForAppUpdate() {
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL("https://api.github.com/repos/gudiyataxipartner/gudiya-taxi-partner/releases/latest");
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(8000);
                connection.setReadTimeout(8000);
                connection.setRequestProperty("Accept", "application/vnd.github+json");
                connection.setRequestProperty("User-Agent", "Gudiya-Taxi-Partner-Android");
                if (connection.getResponseCode() != 200) return;
                StringBuilder response = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) response.append(line);
                }
                JSONObject release = new JSONObject(response.toString());
                String body = release.optString("body", "");
                Matcher matcher = Pattern.compile("Version\\s*:\\s*([0-9]+(?:\\.[0-9]+){1,3})", Pattern.CASE_INSENSITIVE).matcher(body);
                if (!matcher.find()) return;
                String latestVersion = matcher.group(1);
                if (compareVersions(latestVersion, BuildConfig.VERSION_NAME) <= 0) return;
                JSONArray assets = release.optJSONArray("assets");
                if (assets == null) return;
                String apkUrl = null;
                for (int i = 0; i < assets.length(); i++) {
                    JSONObject asset = assets.optJSONObject(i);
                    if (asset != null && "gudiya-taxi-partner.apk".equals(asset.optString("name"))) {
                        apkUrl = asset.optString("browser_download_url", null);
                        break;
                    }
                }
                if (apkUrl == null || apkUrl.isEmpty()) return;
                final String finalUrl = apkUrl;
                runOnUiThread(() -> {
                    if (isFinishing() || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
                    new AlertDialog.Builder(MainActivity.this)
                        .setTitle("नया अपडेट उपलब्ध है")
                        .setMessage("Gudiya Taxi Partner का नया वर्जन " + latestVersion + " उपलब्ध है। बेहतर अनुभव के लिए अपडेट करें।")
                        .setCancelable(true)
                        .setNegativeButton("बाद में", (dialog, which) -> dialog.dismiss())
                        .setPositiveButton("Update Now", (dialog, which) -> {
                            try {
                                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(finalUrl));
                                startActivity(intent);
                            } catch (Exception e) {
                                Toast.makeText(MainActivity.this, "अपडेट लिंक नहीं खुल पाया। कृपया GitHub से APK डाउनलोड करें।", Toast.LENGTH_LONG).show();
                            }
                        })
                        .show();
                });
            } catch (Exception ignored) {
                // Keep app usable if GitHub is temporarily unavailable.
            } finally {
                if (connection != null) connection.disconnect();
            }
        }).start();
    }

    private int compareVersions(String first, String second) {
        try {
            String[] a = first.split("\\.");
            String[] b = second.split("\\.");
            for (int i = 0; i < Math.max(a.length, b.length); i++) {
                int av = i < a.length ? Integer.parseInt(a[i]) : 0;
                int bv = i < b.length ? Integer.parseInt(b[i]) : 0;
                if (av != bv) return Integer.compare(av, bv);
            }
        } catch (Exception ignored) { }
        return first.compareTo(second);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                try { results = WebChromeClient.FileChooserParams.parseResult(resultCode, data); }
                catch (Exception ignored) { }
                if (results == null || results.length == 0) {
                    Uri selected = data.getData();
                    if (selected != null) results = new Uri[]{selected};
                    else if (data.getClipData() != null) {
                        int count = data.getClipData().getItemCount();
                        results = new Uri[count];
                        for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                    }
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }


    @JavascriptInterface
    public String getLocalDuties() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getString(DUTIES_KEY, "[]");
    }

    @JavascriptInterface
    public void saveLocalDuties(String json) {
        if (json == null || json.length() > 2_000_000) return;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(DUTIES_KEY, json).apply();
    }

    private void openExternalPayment(Uri uri) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            Intent chooser = Intent.createChooser(intent, "UPI ऐप चुनें");
            startActivity(chooser);
        } catch (Exception e) {
            Toast.makeText(this, "कोई UPI ऐप नहीं मिला। कृपया PhonePe, Google Pay या BHIM इंस्टॉल करें।", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
