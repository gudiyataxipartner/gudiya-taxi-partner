package com.gudiyataxipartner;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.JavascriptInterface;
import android.content.SharedPreferences;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.Window;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 4107;
    private static final String PREFS = "gudiya_taxi_partner_local_data";
    private static final String DUTIES_KEY = "local_duties_v1";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(9, 43, 58));
        getWindow().setNavigationBarColor(Color.rgb(9, 43, 58));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(245, 248, 250));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(this, "GudiyaNative");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("upi".equalsIgnoreCase(uri.getScheme())) {
                    openExternalPayment(uri);
                    return true;
                }
                if ("tel".equalsIgnoreCase(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_DIAL, uri)); }
                    catch (Exception ignored) { }
                    return true;
                }
                if ("https".equalsIgnoreCase(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (Exception ignored) { }
                    return true;
                }
                return !"file".equalsIgnoreCase(uri.getScheme());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Uri uri = Uri.parse(url);
                if ("upi".equalsIgnoreCase(uri.getScheme())) {
                    openExternalPayment(uri);
                    return true;
                }
                if ("tel".equalsIgnoreCase(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_DIAL, uri)); }
                    catch (Exception ignored) { }
                    return true;
                }
                if ("https".equalsIgnoreCase(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (Exception ignored) { }
                    return true;
                }
                return !"file".equalsIgnoreCase(uri.getScheme());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent;
                try {
                    intent = params.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception firstError) {
                    try {
                        intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("*/*");
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivityForResult(Intent.createChooser(intent, "दस्तावेज़ चुनें"), FILE_CHOOSER_REQUEST);
                        return true;
                    } catch (Exception documentError) {
                      try {
                        intent = new Intent(Intent.ACTION_GET_CONTENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("*/*");
                        startActivityForResult(Intent.createChooser(intent, "दस्तावेज़ चुनें"), FILE_CHOOSER_REQUEST);
                        return true;
                      } catch (Exception secondError) {
                        if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                        filePathCallback = null;
                        Toast.makeText(MainActivity.this, "फाइल चुनने के लिए File Manager उपलब्ध नहीं है।", Toast.LENGTH_LONG).show();
                        return true;
                      }
                    }
                }
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                try { results = WebChromeClient.FileChooserParams.parseResult(resultCode, data); }
                catch (Exception ignored) { }
                if (results == null || results.length == 0) {
                    Uri selected = data.getData();
                    if (selected != null) results = new Uri[]{selected};
                    else if (data.getClipData() != null) {
                        int count = data.getClipData().getItemCount();
                        results = new Uri[count];
                        for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                    }
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }


    @JavascriptInterface
    public String getLocalDuties() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getString(DUTIES_KEY, "[]");
    }

    @JavascriptInterface
    public void saveLocalDuties(String json) {
        if (json == null || json.length() > 2_000_000) return;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(DUTIES_KEY, json).apply();
    }

    private void openExternalPayment(Uri uri) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            Intent chooser = Intent.createChooser(intent, "UPI ऐप चुनें");
            startActivity(chooser);
        } catch (Exception e) {
            Toast.makeText(this, "कोई UPI ऐप नहीं मिला। कृपया PhonePe, Google Pay या BHIM इंस्टॉल करें।", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
