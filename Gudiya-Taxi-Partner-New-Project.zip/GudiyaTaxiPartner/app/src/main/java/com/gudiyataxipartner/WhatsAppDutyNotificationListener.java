package com.gudiyataxipartner;

import android.app.Notification;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.os.Bundle;
import android.util.Log;
import org.json.JSONObject;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Reads visible WhatsApp group notifications only; it does not access WhatsApp storage or chats. */
public class WhatsAppDutyNotificationListener extends NotificationListenerService {
    private static final String TAG = "GudiyaDutyImport";
    private static final String PREFS = "gudiya_taxi_partner_local_data";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || !"com.whatsapp".equals(sbn.getPackageName())) return;
        Bundle extras = sbn.getNotification() == null ? null : sbn.getNotification().extras;
        if (extras == null) return;
        CharSequence conversation = extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE);
        CharSequence sender = extras.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence text = extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
        if (text == null) text = extras.getCharSequence(Notification.EXTRA_TEXT);
        // Group title is required: private chats and unrelated WhatsApp notifications are ignored.
        if (conversation == null || text == null || text.toString().trim().isEmpty()) return;
        String group = conversation.toString().trim();
        String senderName = sender == null ? "" : sender.toString().trim();
        String senderPhone = extractSenderPhone(extras);
        String message = text.toString().trim();
        if (message.length() > 5000) message = message.substring(0, 5000);
        final String body = message;
        final String phone = senderPhone;
        executor.execute(() -> sendDutyNotification(group, senderName, phone, body, sbn.getKey()));
    }

    private String extractSenderPhone(Bundle extras) {
        if (android.os.Build.VERSION.SDK_INT < 28) return null;
        try {
            android.os.Parcelable[] messages = extras.getParcelableArray(Notification.EXTRA_MESSAGES);
            if (messages == null) return null;
            for (int i = messages.length - 1; i >= 0; i--) {
                if (!(messages[i] instanceof Bundle)) continue;
                Bundle item = (Bundle) messages[i];
                android.app.Person person = item.getParcelable("sender_person");
                if (person == null || person.getUri() == null) continue;
                String uri = person.getUri();
                if (uri.startsWith("tel:")) {
                    String digits = uri.substring(4).replaceAll("\\D", "");
                    if (digits.matches("[6-9][0-9]{9}")) return digits;
                    if (digits.matches("91[6-9][0-9]{9}")) return digits.substring(2);
                }
            }
        } catch (Exception ignored) { }
        return null;
    }

    private void sendDutyNotification(String group, String sender, String senderPhone, String message, String notificationKey) {
        android.content.SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String token = prefs.getString("duty_import_token", "");
        String apiBase = prefs.getString("duty_import_api", "");
        if (token.isEmpty() || !apiBase.startsWith("https://")) return;
        HttpURLConnection connection = null;
        try {
            JSONObject payload = new JSONObject();
            payload.put("groupName", group);
            payload.put("senderName", sender);
            if (senderPhone == null) payload.put("senderPhone", JSONObject.NULL); else payload.put("senderPhone", senderPhone); // Only use a phone number exposed by Android sender metadata.
            payload.put("message", message);
            payload.put("notificationKey", notificationKey == null ? "" : notificationKey);
            connection = (HttpURLConnection) new URL(apiBase + "/api/duties/import/whatsapp").openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(15000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Authorization", "Bearer " + token);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            byte[] bytes = payload.toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream out = connection.getOutputStream()) { out.write(bytes); }
            int code = connection.getResponseCode();
            if (code >= 400) Log.w(TAG, "Duty import rejected with HTTP " + code);
        } catch (Exception e) {
            Log.w(TAG, "Could not import WhatsApp duty notification", e);
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    @Override public void onDestroy() {
        executor.shutdown();
        super.onDestroy();
    }
}
