package com.gudiyataxipartner

// CI compatibility marker. The application's MainActivity is implemented in MainActivity.java.
