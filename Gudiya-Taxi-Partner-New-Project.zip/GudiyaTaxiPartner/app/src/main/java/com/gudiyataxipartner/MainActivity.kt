package com.gudiyataxipartner

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val navy = Color.rgb(20, 35, 63)
    private val gold = Color.rgb(245, 184, 46)
    private val cream = Color.rgb(255, 249, 235)
    private val ink = Color.rgb(30, 41, 59)
    private val muted = Color.rgb(105, 117, 135)
    private val page = Color.rgb(246, 248, 252)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var role = "ड्राइवर"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        window.decorView.systemUiVisibility = 0
        showWelcome()
    }

    private fun setup(title: String, subtitle: String? = null) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(page)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(20))
            setBackgroundColor(navy)
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ic_gudiya_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(58), dp(58)))
        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        brand.addView(label("GUDIYA TAXI PARTNER", 12, gold, true))
        brand.addView(label(title, 23, Color.WHITE, true).apply {
            setPadding(0, dp(4), 0, 0)
        })
        if (subtitle != null) brand.addView(label(subtitle, 13, Color.rgb(218, 226, 239), false).apply {
            setPadding(0, dp(4), 0, 0)
        })
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(20), dp(20), dp(20), dp(28))
                content = this
            })
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        content.removeAllViews()
    }

    private fun showWelcome() {
        setup("आपका स्वागत है", "सफर और काम, दोनों आसान")

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(20), dp(16), dp(20))
            background = gradientCard(navy, Color.rgb(39, 62, 101), 22)
        }
        val heroText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        heroText.addView(label("NAMASTE!  •  GUDIYA TAXI", 11, gold, true))
        heroText.addView(label("हर ड्यूटी का\nसही साथी", 25, Color.WHITE, true).apply {
            setPadding(0, dp(8), 0, dp(7))
        })
        heroText.addView(label("ड्राइवर और ट्रैवल पार्टनर के लिए एक आसान प्लेटफ़ॉर्म।", 13, Color.rgb(224, 232, 244), false))
        hero.addView(heroText, LinearLayout.LayoutParams(0, -2, 1f))
        hero.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_gudiya_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Gudiya Taxi Partner लोगो"
        }, LinearLayout.LayoutParams(dp(78), dp(78)))
        content.addView(hero, fullWidth())
        addGap(24)
        content.addView(label("शुरुआत करें", 20, ink, true))
        content.addView(label("आप ऐप का इस्तेमाल किस लिए करेंगे?", 14, muted, false).apply {
            setPadding(0, dp(5), 0, dp(13))
        })

        val choices = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val driver = RadioButton(this).apply {
            text = "  ड्राइवर — ड्यूटी ढूँढें और स्वीकार करें"
            textSize = 15f
            setTextColor(ink)
            id = View.generateViewId()
            isChecked = true
            setPadding(dp(8), dp(12), dp(8), dp(12))
        }
        val agency = RadioButton(this).apply {
            text = "  ट्रैवल एजेंसी — ड्यूटी पोस्ट करें"
            textSize = 15f
            setTextColor(ink)
            id = View.generateViewId()
            setPadding(dp(8), dp(12), dp(8), dp(12))
        }
        choices.addView(driver); choices.addView(agency)
        choices.setOnCheckedChangeListener { _, checked -> role = if (checked == driver.id) "ड्राइवर" else "ट्रैवल पार्टनर" }
        content.addView(card(Color.WHITE).apply {
            setPadding(dp(12), dp(8), dp(12), dp(8))
            addView(choices)
        }, fullWidth())
        content.addView(button("आगे बढ़ें  →", marginTop = 18) { showHome() }, fullWidth())
        content.addView(label("✓  सरल • भरोसेमंद • आपके काम के लिए", 13, muted, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, 0)
        })
    }

    private fun showHome() {
        setup("नमस्ते, $role 👋", "आज का काम यहीं से शुरू करें")
        val welcome = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(22))
            background = gradientCard(navy, Color.rgb(39, 62, 101), 22)
        }
        welcome.addView(label("आपका काम, आपका नेटवर्क", 22, Color.WHITE, true))
        welcome.addView(label("ड्यूटी खोजें, नई ड्यूटी की जानकारी भरें या अपनी ड्यूटी देखें।", 14, Color.rgb(224, 232, 244), false).apply {
            setPadding(0, dp(9), 0, dp(16))
        })
        val badge = TextView(this).apply {
            text = "GUDIYA TAXI PARTNER  〰"
            textSize = 11f
            setTextColor(navy)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(gold, 30)
        }
        welcome.addView(badge, LinearLayout.LayoutParams(-2, -2))
        content.addView(welcome, fullWidth())
        addGap(23)
        content.addView(label("आप क्या करना चाहेंगे?", 20, ink, true))
        content.addView(label("काम शुरू करने के लिए एक विकल्प चुनें", 14, muted, false).apply {
            setPadding(0, dp(4), 0, dp(14))
        })
        actionCard("ड्यूटी खोजें", "दूसरों की पोस्ट की गई ड्यूटी देखें", "⌕", Color.rgb(255, 241, 199)) { showDuties() }
        actionCard("नई ड्यूटी पोस्ट करें", "रूट, तारीख और किराये की जानकारी भरें", "+", Color.rgb(219, 242, 231)) { showPostDuty() }
        actionCard("मेरी ड्यूटी", "अपनी पोस्ट की गई ड्यूटी देखें", "▤", Color.rgb(225, 233, 252)) { showMyDuties() }
        content.addView(button("भूमिका बदलें", marginTop = 8, secondary = true) { showWelcome() }, fullWidth())
        content.addView(label("आपका सफर, आपकी पहचान ✦", 12, muted, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(22), 0, 0)
        })
    }

    private fun actionCard(title: String, description: String, symbol: String, accent: Int, action: () -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(15), dp(14), dp(15))
            background = rounded(Color.WHITE, 16, Color.rgb(232, 236, 243))
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        val iconBox = TextView(this).apply {
            text = symbol
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(navy)
            background = rounded(accent, 14)
        }
        row.addView(iconBox, LinearLayout.LayoutParams(dp(54), dp(54)))
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), 0, dp(6), 0)
        }
        texts.addView(label(title, 16, ink, true))
        texts.addView(label(description, 13, muted, false).apply { setPadding(0, dp(4), 0, 0) })
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(label("›", 28, navy, true))
        val lp = fullWidth(); lp.bottomMargin = dp(10)
        content.addView(row, lp)
    }

    private fun showDuties() {
        setup("ड्यूटी खोजें", "अपने अगले सफर का मौका ढूँढें")
        emptyState("अभी ड्यूटी सूची उपलब्ध नहीं है", "जब लाइव सर्वर जोड़ा जाएगा, तो दूसरी एजेंसियों की खुली ड्यूटी यहाँ दिखाई देगी।")
        content.addView(button("होम पर वापस जाएँ", marginTop = 8, secondary = true) { showHome() }, fullWidth())
    }

    private fun showPostDuty() {
        setup("नई ड्यूटी पोस्ट करें", "ज़रूरी जानकारी भरें")
        val form = card(Color.WHITE).apply { setPadding(dp(16), dp(18), dp(16), dp(18)) }
        form.addView(label("यात्रा की जानकारी", 18, ink, true).apply { setPadding(0, 0, 0, dp(12)) })
        val from = field("कहाँ से शुरू होगी?")
        val to = field("कहाँ तक जाना है?")
        val vehicle = field("गाड़ी का प्रकार (जैसे Sedan, SUV, Innova)")
        val date = field("ड्यूटी की तारीख चुनें")
        date.isFocusable = false
        date.isClickable = true
        date.setOnClickListener {
            val now = java.util.Calendar.getInstance()
            DatePickerDialog(
                this,
                { _, year, month, day ->
                    date.setText(String.format(java.util.Locale.getDefault(), "%02d-%02d-%04d", day, month + 1, year))
                },
                now.get(java.util.Calendar.YEAR),
                now.get(java.util.Calendar.MONTH),
                now.get(java.util.Calendar.DAY_OF_MONTH)
            ).show()
        }
        val time = field("ड्यूटी का समय चुनें")
        time.isFocusable = false
        time.isClickable = true
        time.setOnClickListener {
            val now = java.util.Calendar.getInstance()
            TimePickerDialog(
                this,
                { _, hour, minute ->
                    val amPmHour = if (hour % 12 == 0) 12 else hour % 12
                    val amPm = if (hour < 12) "AM" else "PM"
                    time.setText(String.format(java.util.Locale.ENGLISH, "%02d:%02d %s", amPmHour, minute, amPm))
                },
                now.get(java.util.Calendar.HOUR_OF_DAY),
                now.get(java.util.Calendar.MINUTE),
                false
            ).show()
        }
        val fare = field("किराया (₹)")
        form.addView(from); form.addView(to); form.addView(vehicle)
        form.addView(date); form.addView(time); form.addView(fare)
        content.addView(form, fullWidth())
        content.addView(button("ड्यूटी सेव करें", marginTop = 14) {
            Toast.makeText(this, "अभी सर्वर कनेक्शन नहीं है। यह जानकारी अभी ऑनलाइन सेव नहीं होगी।", Toast.LENGTH_LONG).show()
        }, fullWidth())
        content.addView(button("वापस", marginTop = 8, secondary = true) { showHome() }, fullWidth())
    }

    private fun showMyDuties() {
        setup("मेरी ड्यूटी", "आपकी ड्यूटी एक ही जगह")
        emptyState("अभी कोई ड्यूटी नहीं", "अकाउंट और लाइव बैकएंड जुड़ने के बाद पोस्ट की गई और स्वीकार की गई ड्यूटी यहाँ दिखाई देंगी।")
        content.addView(button("होम पर वापस जाएँ", marginTop = 8, secondary = true) { showHome() }, fullWidth())
    }

    private fun emptyState(title: String, description: String) {
        val box = card(Color.WHITE).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(28), dp(22), dp(28))
        }
        box.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_gudiya_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, LinearLayout.LayoutParams(dp(78), dp(78)))
        box.addView(label(title, 18, ink, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(8))
        })
        box.addView(label(description, 14, muted, false).apply { gravity = Gravity.CENTER })
        content.addView(box, fullWidth())
    }

    private fun field(hintText: String): EditText = EditText(this).apply {
        hint = hintText
        textSize = 15f
        setTextColor(ink)
        setHintTextColor(muted)
        setSingleLine(true)
        setPadding(dp(13), dp(10), dp(13), dp(10))
        background = rounded(Color.rgb(248, 250, 253), 12, Color.rgb(224, 229, 237))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(10)
        layoutParams = lp
    }

    private fun button(text: String, marginTop: Int = 0, secondary: Boolean = false, action: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            textSize = 15f
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(14), dp(4), dp(14), dp(4))
            setTextColor(if (secondary) navy else Color.WHITE)
            background = rounded(if (secondary) Color.rgb(232, 237, 245) else navy, 14)
            elevation = if (secondary) 0f else dp(2).toFloat()
            setOnClickListener { action() }
            val lp = LinearLayout.LayoutParams(-1, dp(54))
            lp.topMargin = dp(marginTop)
            layoutParams = lp
        }
    }

    private fun card(color: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(color, 18, if (color == Color.WHITE) Color.rgb(235, 238, 244) else color)
        elevation = if (color == Color.WHITE) dp(1).toFloat() else 0f
    }

    private fun gradientCard(startColor: Int, endColor: Int, radius: Int): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(startColor, endColor)
    ).apply { cornerRadius = dp(radius).toFloat() }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        includeFontPadding = true
    }

    private fun fullWidth(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(-1, -2)
    private fun addGap(size: Int) { content.addView(View(this), LinearLayout.LayoutParams(1, dp(size))) }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
