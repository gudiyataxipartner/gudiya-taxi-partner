package com.gudiyataxipartner

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val navy = Color.rgb(20, 35, 63)
    private val gold = Color.rgb(239, 177, 45)
    private val ink = Color.rgb(35, 42, 54)
    private val muted = Color.rgb(105, 115, 130)
    private lateinit var root: LinearLayout
    private var role = "Driver"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showWelcome()
    }

    private fun setup(title: String, subtitle: String? = null) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(22))
            setBackgroundColor(Color.rgb(247, 249, 252))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(navy)
        }
        header.addView(label("GUDIYA TAXI PARTNER", 13, gold, true))
        header.addView(label(title, 25, Color.WHITE, true).apply { setPadding(0, dp(8), 0, 0) })
        if (subtitle != null) header.addView(label(subtitle, 14, Color.rgb(220,225,235), false).apply { setPadding(0, dp(5), 0, 0) })
        root.addView(header, LinearLayout.LayoutParams(-1, -2))
        root.addView(ScrollView(this).apply { addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(18), 0, dp(20))
            content = this
        }) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        content.removeAllViews()
    }
    private lateinit var content: LinearLayout

    private fun showWelcome() {
        setup("काम की ड्यूटी, एक जगह", "ड्राइवर और ट्रैवल पार्टनर के लिए नया प्लेटफ़ॉर्म")
        content.addView(label("अपनी भूमिका चुनें", 18, ink, true))
        content.addView(label("आगे चलकर इसी भूमिका के अनुसार सुविधाएँ खुलेंगी।", 14, muted, false).apply { setPadding(0, dp(5), 0, dp(14)) })
        val roles = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val driver = RadioButton(this).apply { text = "ड्राइवर"; textSize = 16f; id = View.generateViewId(); isChecked = true }
        val agency = RadioButton(this).apply { text = "ट्रैवल एजेंसी / ड्यूटी पोस्ट करने वाला"; textSize = 16f; id = View.generateViewId() }
        roles.addView(driver); roles.addView(agency)
        roles.setOnCheckedChangeListener { _, checked -> role = if (checked == driver.id) "Driver" else "Agency" }
        content.addView(roles)
        content.addView(button("आगे बढ़ें", marginTop = 18) { showHome() })
        content.addView(label("नोट: यह नया शुरुआती संस्करण है। अकाउंट, सर्वर और लाइव ड्यूटी अभी जोड़े जाने बाकी हैं।", 13, muted, false).apply { setPadding(0, dp(22), 0, 0) })
    }

    private fun showHome() {
        setup("नमस्ते, $role", "Gudiya Taxi Partner का शुरुआती डैशबोर्ड")
        content.addView(label("आप क्या करना चाहते हैं?", 18, ink, true))
        content.addView(label("ड्यूटी खोजने और पोस्ट करने की स्क्रीन का प्रारंभिक ढाँचा तैयार है। लाइव डेटा के लिए अगला चरण बैकएंड जोड़ना है।", 14, muted, false).apply { setPadding(0, dp(8), 0, dp(16)) })
        content.addView(button("ड्यूटी खोजें", marginTop = 4) { showDuties() })
        content.addView(button("नई ड्यूटी पोस्ट करें", marginTop = 10) { showPostDuty() })
        content.addView(button("मेरी ड्यूटी", marginTop = 10) { showMyDuties() })
        content.addView(button("भूमिका बदलें", marginTop = 10, secondary = true) { showWelcome() })
    }

    private fun showDuties() {
        setup("ड्यूटी खोजें", "खुली ड्यूटी की सूची")
        content.addView(label("अभी कोई लाइव ड्यूटी उपलब्ध नहीं है", 17, ink, true))
        content.addView(label("यह स्क्रीन सर्वर जुड़ने के बाद दूसरी एजेंसियों की खुली ड्यूटी दिखाएगी।", 14, muted, false).apply { setPadding(0, dp(8), 0, dp(18)) })
        content.addView(button("वापस", marginTop = 6, secondary = true) { showHome() })
    }

    private fun showPostDuty() {
        setup("नई ड्यूटी पोस्ट करें", "ड्यूटी की जानकारी भरें")
        val from = field("कहाँ से")
        val to = field("कहाँ तक")
        val date = field("यात्रा की तारीख (जैसे 25-10-2026)")
        val vehicle = field("गाड़ी का प्रकार")
        val fare = field("किराया (₹)")
        content.addView(from); content.addView(to); content.addView(date); content.addView(vehicle); content.addView(fare)
        content.addView(button("ड्यूटी सेव करें", marginTop = 12) {
            Toast.makeText(this, "अभी सर्वर कनेक्शन नहीं है। अगली स्टेज में ड्यूटी सेव करना जोड़ा जाएगा।", Toast.LENGTH_LONG).show()
        })
        content.addView(button("वापस", marginTop = 8, secondary = true) { showHome() })
    }

    private fun showMyDuties() {
        setup("मेरी ड्यूटी", "पोस्ट की गई और स्वीकार की गई ड्यूटी")
        content.addView(label("अभी कोई ड्यूटी नहीं", 17, ink, true))
        content.addView(label("अकाउंट और बैकएंड जोड़ने के बाद आपकी ड्यूटी यहाँ दिखाई देगी।", 14, muted, false).apply { setPadding(0, dp(8), 0, dp(18)) })
        content.addView(button("वापस", marginTop = 6, secondary = true) { showHome() })
    }

    private fun field(hintText: String): EditText = EditText(this).apply {
        hint = hintText
        textSize = 15f
        setSingleLine(true)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.WHITE); cornerRadius = dp(10).toFloat()
            setStroke(dp(1), Color.rgb(220, 225, 233))
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(10)
        layoutParams = lp
    }

    private fun button(text: String, marginTop: Int = 0, secondary: Boolean = false, action: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            textSize = 15f
            isAllCaps = false
            setTextColor(if (secondary) navy else Color.WHITE)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(if (secondary) Color.rgb(232, 237, 245) else navy)
                cornerRadius = dp(10).toFloat()
            }
            setOnClickListener { action() }
            val lp = LinearLayout.LayoutParams(-1, dp(52))
            lp.topMargin = dp(marginTop)
            layoutParams = lp
        }
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
