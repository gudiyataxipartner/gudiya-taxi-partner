# Gudiya Taxi Partner backend setup checklist

1. Create a managed PostgreSQL database and apply `schema.sql`.
2. Deploy this Node.js service on a server with HTTPS.
3. Copy `.env.example` to `.env` in the hosting secret manager. Use unique random secrets.
4. Membership payments are currently disabled while a replacement provider is selected. Login and registration use phone number plus password; no OTP service is used.
5. Do not configure or use Razorpay for this version. The app displays the three plans but payment attempts are intentionally rejected with HTTP 503 until a replacement provider is selected and integrated.
6. The Android UI calls the HTTPS API configured in `app/src/main/assets/config.js`; do not put secret keys in Android. Deploy the updated backend source before using new endpoints.
7. For duty acceptance, apply the updated `backend/schema.sql` to the production PostgreSQL database before deploying the updated backend. This adds `duties.accepted_by_user_id`. The app then allows logged-in driver accounts to accept an open duty; the server atomically marks it accepted so another driver cannot accept the same duty. The accepting driver can find it under **मेरी ड्यूटी → आपके द्वारा स्वीकार की गई ड्यूटी**.
8. Driver and vendor verification uploads are encrypted with AES-256-GCM before PostgreSQL storage. The encryption key is derived from `DOCUMENT_ENCRYPTION_KEY` when configured, otherwise `JWT_SECRET`. For production, set a dedicated high-entropy `DOCUMENT_ENCRYPTION_KEY` in the Render secret environment and keep it stable; changing it without re-encrypting existing records makes old uploads unreadable. Restrict admin API key access and review documents only through the protected admin endpoint.
9. Run tests for password login, single-device revocation, verification uploads/review, replacement-provider payment verification, membership expiry, and the 5-minute privacy rule.
10. Add a routing provider for road distance; until then distance must remain clearly marked approximate/unavailable.

## Important
The app package is a source starter. Real OTP, duty sharing, payment activation, routing and document upload require deployment/configuration and end-to-end tests. Do not advertise it as live until those are completed.
