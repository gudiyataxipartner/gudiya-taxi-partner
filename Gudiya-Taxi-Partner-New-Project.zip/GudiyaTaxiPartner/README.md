# Gudiya Taxi Partner — Android Source

This project builds the Android app with the redesigned mobile-first Gudiya Taxi Partner interface embedded in the native Android WebView.

## Included screens and user flows
- Welcome/home dashboard with a custom taxi illustration, brand logo, color-coded action cards, and trust-focused tagline
- Duty search with route, date, and vehicle filters; readable duty cards
- Duty posting with vehicle type, date, **time**, payout, and optional notes
- My posted and accepted duties
- Phone number + password login/register (no OTP) and driver/vendor document verification
- Membership plans: ₹51 for 1 month, ₹151 for 3 months, and ₹301 for 6 months

## Build
Open this folder as an Android project or run `gradle assembleDebug` with JDK 17 and Android SDK installed. The GitHub Actions workflow should build and validate the APK before it is installed on a phone.

## Backend and payment notes
The backend source and SQL schema are included in `backend/`. Apply the latest `backend/schema.sql` migration before deploying, because duty time and selected membership plan details are stored server-side. Configure a real HTTPS API endpoint in `app/src/main/assets/config.js` before expecting live accounts, cross-device duty sharing, document submission, or membership status to work. Razorpay has been removed from the app and backend source. Membership plans remain visible at ₹51 / ₹151 / ₹301, but payment is temporarily unavailable while a replacement provider is selected. The backend refuses payment requests and only grants membership when an active subscription has a recorded payment ID and a future expiry.

The APK build does not deploy the backend. Test the generated APK on a device after GitHub Actions reports both build and validation success.


### Admin membership
Deploy the `backend/` folder to the existing Render API service. Set `ADMIN_API_KEY` to a strong secret of at least 32 characters in Render Environment. Open `/admin-membership`, enter that key and search by the user's registered 10-digit phone number. The admin can set Paid without payment or set Unpaid. Never share the admin key.
