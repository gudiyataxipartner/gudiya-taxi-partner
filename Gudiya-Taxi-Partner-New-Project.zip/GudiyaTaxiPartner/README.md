# Gudiya Taxi Partner — Android Source

This project builds the Android app with the redesigned mobile-first Gudiya Taxi Partner interface embedded in the native Android WebView.

## Included screens and user flows
- Welcome/home dashboard with a custom taxi illustration, brand logo, color-coded action cards, and trust-focused tagline
- Duty search with route, date, and vehicle filters; readable duty cards
- Duty posting with vehicle type, date, **time**, payout, and optional notes
- My posted and accepted duties
- Phone number + password login/register (no OTP) and driver/vendor document verification
- Membership plans: ₹51 for 1 month, ₹151 for 3 months, and ₹301 for 6 months

## Build
Open this folder as an Android project or run `gradle assembleDebug` with JDK 17 and Android SDK installed. The GitHub Actions workflow should build and validate the APK before it is installed on a phone.

## Backend and direct UPI payment notes
The backend source and SQL schema are included in `backend/`. The Android app offers direct UPI payment to `BHARATPE2Q0G0U8Z8L34528@unitype` for plans of ₹51 / ₹151 / ₹301. After paying, the user submits the UPI transaction reference (UTR). Submitting a UTR does **not** activate membership: an admin must confirm the amount and UTR in the bank/UPI account and approve the request.

Deploy the updated backend before using this feature. The backend schema auto-runs at startup and creates the `membership_payment_requests` table. Set a strong `ADMIN_API_KEY` (at least 32 characters) in the backend environment. On the deployed API, open `/admin-membership` in a browser, enter the admin key for that session, and review pending UPI requests. Do not approve a request based only on a screenshot or user-provided UTR; verify the bank credit first. The admin page does not save the key in browser storage.

The APK build does not deploy the backend. The Android app and backend are separate deployments; test both after deployment. UPI intent launching depends on an installed UPI app. This direct UPI method is manual and is not UPI AutoPay or automatic payment verification.
The APK build does not deploy the backend. Test the generated APK on a device after GitHub Actions reports both build and validation success.
