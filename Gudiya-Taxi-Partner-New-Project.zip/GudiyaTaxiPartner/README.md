# Gudiya Taxi Partner — Android Source

This project builds the Android app with the redesigned mobile-first Gudiya Taxi Partner interface embedded in the native Android WebView.

## Included screens and user flows
- Welcome/home dashboard with a custom taxi illustration, brand logo, color-coded action cards, and trust-focused tagline
- Duty search with route, date, and vehicle filters; readable duty cards
- Duty posting with vehicle type, date, **time**, payout, and optional notes
- My posted and accepted duties
- Account login/register and driver/vendor document verification
- Membership plans: ₹51 for 1 month, ₹151 for 3 months, and ₹301 for 6 months

## Build
Open this folder as an Android project or run `gradle assembleDebug` with JDK 17 and Android SDK installed. The GitHub Actions workflow should build and validate the APK before it is installed on a phone.

## Backend and payment notes
The backend source and SQL schema are included in `backend/`. Apply the latest `backend/schema.sql` migration before deploying, because duty time and selected membership plan details are stored server-side. Configure a real HTTPS API endpoint in `app/src/main/assets/config.js` before expecting live accounts, cross-device duty sharing, document submission, or membership status to work. Configure the three Razorpay plan IDs in the backend environment before enabling membership payments. Until that is done, no membership payment is taken and membership is not activated.

The APK build does not deploy the backend. Test the generated APK on a device after GitHub Actions reports both build and validation success.
