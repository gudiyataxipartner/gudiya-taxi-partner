# Gudiya Taxi Partner — fresh project

यह प्रोजेक्ट Taxi Mitra से अलग, नया Android project है। इसमें पुराने source files शामिल नहीं हैं।

## अभी क्या तैयार है
- Native Android app scaffold (Kotlin)
- Gudiya Taxi Partner branding
- Driver / Travel Agency role selection
- Starter screens: Home, Search Duties, Post Duty, My Duties
- GitHub Actions workflow that builds a debug APK and uploads it as an artifact

## अभी क्या बाकी है
यह शुरुआती UI scaffold है, production-ready app नहीं। Login/signup, database, API/backend, real duty posting/search/acceptance, admin panel, subscriptions, payment integration, push notifications, and server deployment are not connected yet.

## Build on GitHub
1. Create a **new, separate GitHub repository** named `gudiya-taxi-partner`.
2. Upload the contents of this folder to the repository root, keeping `.github/workflows/android.yml`.
3. Open **Actions** and run **Gudiya Taxi Partner Android Build**.
4. Only download the artifact if the workflow is green and the APK validation step passes.

## Package
`in.gudiyataxipartner`


ड्यूटी पोस्ट फ़ॉर्म में तारीख और समय चुनने के लिए अलग-अलग date/time picker दिए गए हैं।
