# Gudiya Taxi Partner — Point 2 and Point 4 corrections

## Point 2: Duty contact actions
- Direct Call uses the duty poster's phone number through the Android `tel:` handler.
- WhatsApp opens a chat with the duty poster and pre-fills the complete duty summary: pickup/drop city and address, date/time, vehicle, role, distance, payout, notes, poster name and contact number.
- The separate share button still allows the user to enter another Indian mobile number and share the duty details there.
- Contact buttons are displayed only when the API has made poster contact details available.

## Point 4: Non-subscriber information timer
- Active subscribers get full duty details immediately.
- Non-subscribers see a locked/private detail state during the first 5 minutes after the duty was posted.
- The timer counts down the remaining lock time. At zero, the duty list is fetched again from the backend and full details unlock without requiring a subscription.
- The API does not return private address, poster contact, payout or notes during the lock period.

## Validation
- `node --check backend/src/server.js` passed.
- Inline JavaScript extracted from `app/src/main/assets/index.html` passed `node --check`.
- This is source-level validation only; a complete Android build and live API test have not been run here.
