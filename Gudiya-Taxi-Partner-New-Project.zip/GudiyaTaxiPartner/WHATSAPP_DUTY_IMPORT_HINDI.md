# WhatsApp Duty Auto Import – Gudiya Taxi Partner

## क्या जोड़ा गया है
- User App में Account पेज पर WhatsApp Duty Auto Import सेटिंग।
- Android Notification Listener केवल WhatsApp group notifications पढ़ता है; private chats और दूसरे ऐप ignore होते हैं।
- Notification में उपलब्ध group title, sender display name और Android द्वारा expose किया गया sender telephone URI भेजा जाता है। नंबर उपलब्ध न होने पर खाली रहेगा।
- Backend पर अलग authenticated import endpoint, conservative duty parser और duplicate-message hash।
- Duty card में WhatsApp group तथा source poster का उपलब्ध नाम/नंबर।
- Admin App के source में कोई बदलाव नहीं किया गया।

## जरूरी सीमाएँ
- यह WhatsApp की official Group API integration नहीं है। यह Android पर दिखने वाली notifications पर निर्भर है।
- संबंधित WhatsApp groups की notifications चालू होनी चाहिए; muted, hidden, truncated या notification न देने वाले messages import नहीं होंगे।
- WhatsApp notification sender का फोन नंबर सामान्यतः expose नहीं करता। इस स्थिति में नंबर अनुमान से नहीं भरा जाएगा।
- Parser केवल उन messages को import करता है जिनमें route और पहचानी जा सकने वाली vehicle category मिलती है। अलग-अलग message formats की वास्तविक group samples से tuning जरूरी है।
- Android Settings में Notification Access user को स्वयं enable करना होगा।

## सुरक्षित rollout
1. पहले Backend API update deploy करें। Schema columns lazy और additive तरीके से बनते हैं; existing duty rows delete/overwrite नहीं होतीं।
2. User App v1.1.6 का test APK बनाएं और पहले एक WhatsApp group पर अनुमति चालू करें।
3. एक test duty भेजें; Find Duties में route, group, sender name और उपलब्ध phone verify करें।
4. फिर धीरे-धीरे बाकी groups की notifications enable करें।
5. पुराने APK को uninstall न करें; same package ID और release signing key से upgrade build करें।

## Build
GitHub Actions workflow `android.yml` से Android APK build करें। Release signing secrets वही रहने चाहिए जो मौजूदा APK के लिए उपयोग किए जाते हैं।
