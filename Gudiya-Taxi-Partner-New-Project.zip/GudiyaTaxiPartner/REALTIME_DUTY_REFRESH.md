# Gudiya Taxi Partner — duty refresh update

The duty search list now polls the Gudiya API every 3 seconds while the Search Duties screen is open. The refresh pauses when the app is backgrounded and refreshes immediately when the app returns to the foreground. Automatic refreshes do not replace the search button with a loading state, and overlapping automatic requests are prevented.

This is near-real-time polling (up to about 3 seconds under a working network/API), not a persistent WebSocket push connection. Duties must be successfully posted to the shared Gudiya backend/database to appear on another device. Local-only/demo duties are not shared between devices.

The source project also retains the prior point 2 contact/WhatsApp actions and point 4 subscriber/non-subscriber five-minute details policy. Backend and Android build/deployment must still be run and tested before treating the live app as verified.
