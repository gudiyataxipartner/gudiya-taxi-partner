# Gudiya Taxi Partner implementation update

## Included in this source update
- Duties are stored in the Gudiya PostgreSQL backend; the app refreshes the duty feed every 20 seconds while the search screen is open.
- Duty cards show the poster's phone and offer direct dial, WhatsApp with duty details prefilled, and sharing to a separately entered WhatsApp number.
- Non-subscribers see a five-minute visible countdown. After the free window expires, the UI hides private addresses, contact, notes and payout; the API also stops returning those private fields. Active subscribers retain access.
- Razorpay payment UI and webhook have been removed. BharatPe UPI membership payment with manual UTR verification is included.
- Login/register use Gudiya-specific local storage keys.
- Driver document submission requires Aadhaar, driving licence and vehicle RC; vendor submission requires Aadhaar; driver+vendor submission accepts all four document entries (separate driver Aadhaar and vendor Aadhaar records).
- Backend initializes `schema.sql` before listening, so missing database tables do not surface as a generic login Server error on a fresh database.
- JSON body size is 25 MB to support four document uploads of up to 4 MB each after Base64 encoding.

## Deployment requirements
- Deploy `backend/` to the existing Gudiya API service and ensure `DATABASE_URL` and a 32+ character `JWT_SECRET` are configured.
- BharatPe UPI submissions are pending until an admin verifies the transaction in the actual payment statement. Membership access requires an active subscription or an admin Paid override.
- This package was syntax-checked with Node.js; an Android APK build and live PostgreSQL/Render integration test must still run in GitHub Actions/Render.


## Real-time duty list refresh
Duty search now refreshes from the shared API every 3 seconds while visible, and refreshes on app resume/focus. It avoids overlapping silent refresh requests. This is near-real-time polling; backend deployment and APK build/testing are required.

## Firebase Cloud Messaging integration (initial implementation)
- Android Firebase configuration is in `app/google-services.json` and matches `com.gudiyataxipartner`.
- Android includes Firebase Messaging, requests Android 13+ notification permission, creates a high-importance notification channel with sound/vibration, and displays data-message notifications.
- After password login (or app resume/start with an existing session), the app obtains its FCM token and registers it through `POST /api/push/register-token`.
- Backend schema stores tokens; code sends data-only high-priority push notifications for newly posted duties, duty acceptance, and document review status changes.
- To actually send pushes, deploy the backend changes to the API service and set `FIREBASE_SERVICE_ACCOUNT_JSON` as a Render secret containing the Firebase service-account JSON. Never commit this private service-account key to GitHub.
- FCM delivery is not considered verified until backend deployment, Render secret setup, a successful GitHub Actions APK build, notification permission approval on the phone, and end-to-end testing on a second account/device. Admin membership override and UPI payment review routes are included; end-to-end notifications still require deployment and testing.


## Welcome banner update (2026-10-25)
- The home banner uses the logged-in user’s actual name in “प्रिय [नाम] जी, Gudiya Taxi Partner में आपका हार्दिक स्वागत है!”
- The finalized slogan is displayed underneath with a highlighted, high-contrast design: “हर साथी की अपनी पहचान, हर रिश्ते में विश्वास — यही है Gudiya Taxi Partner की खास बात।”
- The profile information areas show only the user name and contact number.
- Razorpay UI, client initiation, server SDK, and webhook endpoint have been removed. Plan prices remain visible; choosing a plan displays a payment-coming-soon message. This source ZIP alone does not deploy backend changes.


## Source audit corrections (2026-10-26)
- Fixed incorrectly double-escaped numeric-ID regular expressions in the duty accept and mark-booked API handlers. They now accept valid numeric duty IDs and reject non-numeric IDs.
- Fixed the push-token whitespace check so it detects actual whitespace.
- Moved the global API rate limiter before JSON body parsing so over-limit requests are rejected before the server parses large JSON payloads.
- Validation completed: `node --check` passed for `backend/src/server.js` and the inline JavaScript in `app/src/main/assets/index.html`. A small regex behavior check also passed.
- Not yet verified: Android Gradle/APK build, Render deployment, PostgreSQL live behavior, BharatPe UPI payment review, push delivery, or multi-device end-to-end duty flow. The Admin Panel and admin Paid/Unpaid endpoint are included; live deployment and integration testing remain outstanding.


## Admin membership override update (2026-10-26)
- Added `/admin-membership` admin page with registered-phone user search and Paid/Unpaid actions.
- Added protected `GET /api/admin/membership/user` and `POST /api/admin/users/:id/membership-override` API routes. Both require the `x-admin-key` header and a configured `ADMIN_API_KEY` of at least 32 characters.
- Added `admin_membership_overrides` table to `backend/schema.sql`; backend startup applies the schema before listening.
- Admin Paid override grants membership access without a payment; Unpaid override explicitly disables membership access. The override is checked by the shared membership-access function, so it affects the server-side duty-detail lock as well as the membership status endpoint.
- Razorpay remains removed; BharatPe UPI payment submission is available with manual UTR review. Plan prices remain ₹51 / ₹151 / ₹301.
- Validation: Node syntax checks and ZIP structure checks run before delivery. Android APK installation, Render deployment, and live database/device integration still require verification.


## BharatPe UPI membership payment
- Added UPI intent for `BHARATPE2Q0G0U8Z8L34528@unitype` with ₹51 / ₹151 / ₹301 plans.
- Added authenticated UTR submission and duplicate-UTR protection.
- Added pending-payment admin review endpoints and controls in `/admin-membership`.
- Approval activates the selected subscription for its plan period and marks the membership override Paid; rejection leaves membership inactive.
- UPI ID / UTR alone do not prove that money arrived. Admin must verify the transaction in the actual payment statement before approving.
