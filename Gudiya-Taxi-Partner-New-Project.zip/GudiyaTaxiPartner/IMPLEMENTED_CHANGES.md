# Gudiya Taxi Partner implementation update

## Included in this source update
- Duties are stored in the Gudiya PostgreSQL backend; the app refreshes the duty feed every 20 seconds while the search screen is open.
- Duty cards show the poster's phone and offer direct dial, WhatsApp with duty details prefilled, and sharing to a separately entered WhatsApp number.
- Non-subscribers see a five-minute visible countdown. After the free window expires, the UI hides private addresses, contact, notes and payout; the API also stops returning those private fields. Active subscribers retain access.
- Membership webhook updates the subscription period so active membership checks work.
- Login/register use Gudiya-specific local storage keys.
- Driver document submission requires Aadhaar, driving licence and vehicle RC; vendor submission requires Aadhaar; driver+vendor submission accepts all four document entries (separate driver Aadhaar and vendor Aadhaar records).
- Backend initializes `schema.sql` before listening, so missing database tables do not surface as a generic login Server error on a fresh database.
- JSON body size is 25 MB to support four document uploads of up to 4 MB each after Base64 encoding.

## Deployment requirements
- Deploy `backend/` to the existing Gudiya API service and ensure `DATABASE_URL` and a 32+ character `JWT_SECRET` are configured.
- Configure Razorpay key/secret, the three membership plan IDs and the webhook secret before taking subscription payments. Membership must only activate after verified webhook delivery.
- This package was syntax-checked with Node.js; an Android APK build and live PostgreSQL/Render integration test must still run in GitHub Actions/Render.


## Real-time duty list refresh
Duty search now refreshes from the shared API every 3 seconds while visible, and refreshes on app resume/focus. It avoids overlapping silent refresh requests. This is near-real-time polling; backend deployment and APK build/testing are required.
